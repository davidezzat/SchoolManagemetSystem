﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace School_managment_system.ViewModels
{
    public class Login
    {
        public string SNN { get; set; }
        public string Password { get; set; }
    }
}