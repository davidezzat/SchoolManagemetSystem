﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace School_managment_system.ViewModels
{
    public class ResultViewModel
    {
        public string StudentId { get; set; }
        public int ExamId { get; set; }

        public int StudentResult { get; set; }
    }
}