﻿//using School_managment_system.Services;
//using School_managment_system.ViewModels;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Net.Http;
//using System.Web.Http;

//namespace School_managment_system.Controllers
//{
//    public class SessionController : ApiController
//    {

//        public IEnumerable<SessionViewModel> Get()
//        {
//            return SessionService.GetAll();

//        }


//        public SessionViewModel Get(int id)
//        {
//            return SessionService.GetOne(id);
//        }




//        public void Post(SessionViewModel sessionViewModel)
//        {
//            SessionService.Create(sessionViewModel);

//        }
//    }
//}
