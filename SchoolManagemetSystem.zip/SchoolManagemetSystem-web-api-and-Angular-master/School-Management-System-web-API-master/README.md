# Teechnologies:
  - Entityframework (EF6). 
  - SQL.
  - Linq.
  - Asp.net web API.

# School Mangement System where:
## Teacher:
    - can take the addendance of class in every session.
    - can make a exam and put the results of the students.
## Parent
can follow his son's level by:
    - seeing the attendances of his son.
    - seeing the results of his son.
