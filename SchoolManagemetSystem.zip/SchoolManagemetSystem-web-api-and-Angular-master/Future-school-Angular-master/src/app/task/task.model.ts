export class Task {
    ID:number=0;
    Title:string;
    Done:boolean=false;
    UserID:number=0;
}