import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parentpage',
  templateUrl: './parentpage.component.html',
  styleUrls: ['./parentpage.component.css']
})
export class ParentpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
