export class Level {
    LevelId: number;
    Name: string;
}