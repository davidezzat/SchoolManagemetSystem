export class Exam{
    ExamId:number;
    ExamName:string;
    MaxExamDegree:number;
    CourseName:string;
}