export class Course {

    CourseId: number;
    Name: string;
    LevelName: string;
}
