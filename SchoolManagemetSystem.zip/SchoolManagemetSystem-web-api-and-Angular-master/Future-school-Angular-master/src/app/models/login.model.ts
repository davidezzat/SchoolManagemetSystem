export class Login{
    SNN:string;
    Password:string;
}