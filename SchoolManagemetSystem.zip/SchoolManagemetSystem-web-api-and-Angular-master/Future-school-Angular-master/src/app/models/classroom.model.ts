export class ClassRoom {
    ClassId: number;
    Name: string;
    LevelName: string;
}