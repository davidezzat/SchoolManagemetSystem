export class Result{
    StudentId:string;
    ExamId:number;
    StudentResult:number;
}