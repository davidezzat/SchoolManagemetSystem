export class Student {
    StudentSNN: string;
        FName: string;
        LName: string;
        Age: number;
        Email: string;
        Phone: string;
        Gender: string;
        City: string;
        Street: string;
        ClassName: string;
        LevelName: string;
        Password:string;
        ParentFName: string;
        ParentLName: string;
        ParentSNN: string;
    }