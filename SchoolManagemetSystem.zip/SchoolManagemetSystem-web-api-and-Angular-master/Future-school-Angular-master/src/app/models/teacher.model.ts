export class Teacher {
        TeacherSNN: string;
        FName: string;
        LName: string;
        Email: string;
        Password: string;
        Gender: string;
        Age: number;
        City: string;
        Street: string;
        Phone: string;
        CourseName: string[];






    }