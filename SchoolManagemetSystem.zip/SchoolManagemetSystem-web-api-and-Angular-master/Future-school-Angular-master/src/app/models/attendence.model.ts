export class Attendence{
    StudentSNN:string;   
    IsAttended:boolean;
    StudentName:string;
    ///////
    SessionDate:Date;
    CourseName:string;
    TeacherSNN:string;
    TeacherName:string;
}