import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-staffevaluate',
  templateUrl: './staffevaluate.component.html',
  styleUrls: ['./staffevaluate.component.css']
})
export class StaffevaluateComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
